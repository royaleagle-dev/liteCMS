﻿using System.Runtime.InteropServices;

namespace WinSCP
{
    internal static class Constants
    {
        public const ClassInterfaceType ClassInterface = ClassInterfaceType.AutoDispatch;
    }
}
