// MFC Julian date build numbers (YDDD)

#define _MFC_BUILD 8063
#define _MFC_USER_BUILD "8063"

#ifndef _MFC_RBLD
#define _MFC_RBLD 0
#define _MFC_USER_RBLD "0"
#endif
