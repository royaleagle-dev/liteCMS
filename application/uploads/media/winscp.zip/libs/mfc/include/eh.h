#ifndef _INC_EH
#define _INC_EH
  #ifdef __BORLANDC__
    // Borland place holder for EH.H
    // Nothing is required from here right now.
  #endif // __BORLANDC__
#endif // _INC_EH