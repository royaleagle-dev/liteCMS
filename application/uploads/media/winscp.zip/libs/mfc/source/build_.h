// MFC Julian date build numbers (YDDD)

#define _MFC_BUILD 7022
#define _MFC_USER_BUILD "7022"
