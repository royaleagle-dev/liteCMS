/*------------------------------------------------------------------------*/
/*                                                                        */
/*  BORMEM.CPP                                                            */
/*                                                                        */
/* This file is to contain any declarations or definitions necessary      */
/* in order to allow MFC to build with Borland's compiler.                */
/*                                                                        */
/*------------------------------------------------------------------------*/

/*
 *      C/C++ Run Time Library - Version 9.0
 *
 *      Copyright (c) 1992, 1998 by Borland International
 *      All Rights Reserved.
 *
 */
/* $Revision:   1.4  $ */


