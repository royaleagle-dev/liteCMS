/*
  This is a helper stub file for BORLAND support only

  __BORLANDC__

*/

class COleControlContainer
{
  public:
    ~COleControlContainer();
};

COleControlContainer::~COleControlContainer()
{
}